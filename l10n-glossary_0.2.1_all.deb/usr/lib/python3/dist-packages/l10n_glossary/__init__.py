"""Glossary Editor for localization."""

__version__ = "0.1.0"
